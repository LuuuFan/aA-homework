def greeting
  puts "Hello Git!"
end
