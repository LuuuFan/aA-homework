def noun_fun
  nil
end
